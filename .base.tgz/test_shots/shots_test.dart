// Design screenshots (not part of the suite): flutter test test_shots/
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:archangel/data/app_state.dart';
import 'package:archangel/models/devops_model.dart';
import 'package:archangel/screens/setup/setup_landing_screen.dart';
import 'package:archangel/services/admin_mode_service.dart';
import 'package:archangel/services/archangeld_connection.dart';
import 'package:archangel/services/containers_service.dart';
import 'package:archangel/services/devices_service.dart';
import 'package:archangel/services/devops_service.dart';
import 'package:archangel/services/files_service.dart';
import 'package:archangel/services/monitoring_service.dart';
import 'package:archangel/services/server_registry.dart';
import 'package:archangel/services/update_check_service.dart';
import 'package:archangel/services/wireguard_controller.dart';
import 'package:archangel/ui/boot/boot_splash.dart';
import 'package:archangel/ui/screens/apps/run_app_page.dart';
import 'package:archangel/ui/shell/archangel_shell.dart';
import 'package:archangel/ui/shell/desktop_customize.dart';
import 'package:archangel/ui/shell/desktop_prefs.dart';
import 'package:archangel/ui/theme.dart';

import '../test/screens/home_screen_test.dart' as h;
import '../test/test_utils.dart';

class ShotBackend extends ArchangeldConnection {
  @override
  bool get isPaired => true;
  @override
  String? get host => '10.8.0.1:8443';
  @override
  bool? get reachable => true;
  @override
  Future<void> checkReachable({Duration timeout = const Duration(seconds: 5)}) async {}
}

Future<void> _fonts() async {
  Future<ByteData> f(String p) async => ByteData.view((await File(p).readAsBytes()).buffer);
  final inter = FontLoader('Inter');
  for (final w in ['Regular', 'Medium', 'SemiBold', 'Bold']) {
    inter.addFont(f('assets/fonts/Inter-$w.ttf'));
  }
  await inter.load();
  final mono = FontLoader('IBMPlexMono');
  for (final w in ['Regular', 'Medium', 'SemiBold']) {
    mono.addFont(f('assets/fonts/IBMPlexMono-$w.ttf'));
  }
  await mono.load();
  final root = Platform.environment['FLUTTER_ROOT']!;
  final icons = FontLoader('MaterialIcons')..addFont(f('$root/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf'));
  await icons.load();
}

final _key = GlobalKey();

Future<void> _save(WidgetTester tester, String name) async {
  await tester.runAsync(() async {
    final b = _key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final img = await b.toImage(pixelRatio: 1.5);
    final bytes = await img.toByteData(format: ui.ImageByteFormat.png);
    Directory('../../.shots').createSync(recursive: true);
    File('../../.shots/$name.png').writeAsBytesSync(bytes!.buffer.asUint8List());
  });
}

Future<AppState> _shell(WidgetTester tester, Size size, Brightness b, {AxLayout layout = AxLayout.simple, AxSection? go, DesktopPrefs? prefs}) async {
  final registry = ServerRegistry();
  await tester.runAsync(() async {
    await useTempKvStore();
    await registry.add(
      ServerProfile(id: 'a', name: 'archangel-01', host: '203.0.113.24', token: 't', wgConfig: '', createdAt: DateTime.utc(2026)),
    );
    await registry.setActive('a');
  });
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.resetPhysicalSize);
  final app = AppState()..layout = layout;
  final mon = h.FakeMonitoring(fakeMetrics: h.metrics(cpu: 14, memPct: 39, mounts: const []));
  await tester.pumpWidget(
    RepaintBoundary(
      key: _key,
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider<AppState>.value(value: app),
          ChangeNotifierProvider<ServerRegistry>.value(value: registry),
          ChangeNotifierProvider<DesktopPrefs>.value(value: prefs ?? DesktopPrefs()),
          ChangeNotifierProvider(create: (_) => WireGuardController()),
          ChangeNotifierProvider<ArchangeldConnection>.value(value: ShotBackend()),
          ChangeNotifierProvider<MonitoringService>.value(value: mon),
          ChangeNotifierProvider(create: (_) => FilesService()),
          ChangeNotifierProvider<ContainersService>.value(
            value: h.FakeContainers([
              h.container('immich', running: true),
              h.container('vaultwarden', running: true),
              h.container('nextcloud', running: false),
            ]),
          ),
          ChangeNotifierProvider<DevopsService>.value(
            value: h.FakeDevops(const [DevRowModel(name: 'caddy', meta: '', status: 'active', ok: true, actions: [])]),
          ),
          ChangeNotifierProvider(create: (_) => DevicesService()),
          ChangeNotifierProvider(create: (_) => AdminModeService()),
          ChangeNotifierProvider<UpdateCheckService>.value(value: h.FakeUpdates('0.5.1')),
        ],
        child: MaterialApp(debugShowCheckedModeBanner: false, theme: buildTheme(b), home: const ArchangelShell()),
      ),
    ),
  );
  if (go != null) app.go(go);
  for (var i = 0; i < 6; i++) {
    await tester.pump(const Duration(milliseconds: 100));
  }
  return app;
}

void main() {
  setUpAll(_fonts);
  testWidgets('desk aurora right', (t) async {
    final p = DesktopPrefs()
      ..applyJson({'wallpaper': 'aurora', 'dock': 'right', 'size': 'large'});
    await _shell(t, const Size(1280, 800), Brightness.dark, layout: AxLayout.desktop, prefs: p);
    await _save(t, 'desk-aurora-right');
  });
  testWidgets('desk mist left', (t) async {
    final p = DesktopPrefs()
      ..applyJson({'wallpaper': 'mist', 'dock': 'left', 'size': 'small', 'widget': false});
    await _shell(t, const Size(1280, 800), Brightness.light, layout: AxLayout.desktop, prefs: p);
    await _save(t, 'desk-mist-left');
  });
  for (final b in Brightness.values) {
    testWidgets('customize $b', (t) async {
      await _shell(t, const Size(1280, 800), b, layout: AxLayout.desktop);
      showDesktopCustomize(t.element(find.byType(ArchangelShell)));
      for (var i = 0; i < 4; i++) {
        await t.pump(const Duration(milliseconds: 100));
      }
      await _save(t, 'customize-${b.name}');
    });
  }
  for (final b in Brightness.values) {
    final n = b == Brightness.dark ? 'dawn' : 'pearl';
    testWidgets('phone $n', (t) async {
      await _shell(t, const Size(390, 844), b);
      await _save(t, 'phone-home-$n');
    });
    testWidgets('mac $n', (t) async {
      await _shell(t, const Size(1280, 800), b);
      await _save(t, 'mac-home-$n');
    });
    testWidgets('desk $n', (t) async {
      await _shell(t, const Size(1280, 800), b, layout: AxLayout.desktop);
      await _save(t, 'desk-$n');
    });
  }
  testWidgets('phone more dawn', (t) async {
    await _shell(t, const Size(390, 844), Brightness.dark, go: AxSection.apps);
    await _save(t, 'phone-apps-dawn');
  });
  testWidgets('mac apps pearl', (t) async {
    await _shell(t, const Size(1280, 800), Brightness.light, go: AxSection.apps);
    await _save(t, 'mac-apps-pearl');
  });
  for (final b in Brightness.values) {
    final n = b == Brightness.dark ? 'dawn' : 'pearl';
    testWidgets('run app $n', (t) async {
      t.view.physicalSize = const Size(390, 844);
      t.view.devicePixelRatio = 1.0;
      addTearDown(t.view.resetPhysicalSize);
      final svc = h.FakeContainers(const []);
      await t.pumpWidget(
        RepaintBoundary(
          key: _key,
          child: MultiProvider(
            providers: [ChangeNotifierProvider<ArchangeldConnection>.value(value: ShotBackend())],
            child: MaterialApp(debugShowCheckedModeBanner: false, theme: buildTheme(b), home: RunAppPage(service: svc)),
          ),
        ),
      );
      await t.pump(const Duration(milliseconds: 300));
      await _save(t, 'run-pick-$n');
      await t.tap(find.text('Vaultwarden'));
      await t.pump(const Duration(milliseconds: 400));
      await t.tap(find.text('Public'));
      await t.pump(const Duration(milliseconds: 300));
      await _save(t, 'run-config-$n');
    });
  }
  testWidgets('setup pearl', (t) async {
    t.view.physicalSize = const Size(390, 844);
    t.view.devicePixelRatio = 1.0;
    addTearDown(t.view.resetPhysicalSize);
    await t.pumpWidget(
      RepaintBoundary(key: _key, child: MaterialApp(theme: buildTheme(Brightness.light), home: const SetupLandingScreen())),
    );
    await t.pump(const Duration(milliseconds: 100));
    await _save(t, 'setup-pearl');
  });
  for (final ms in [1400, 2500, 3000, 3600]) {
    testWidgets('boot $ms', (t) async {
      t.view.physicalSize = const Size(390, 844);
      t.view.devicePixelRatio = 1.0;
      addTearDown(t.view.resetPhysicalSize);
      await t.pumpWidget(
        RepaintBoundary(
          key: _key,
          child: MaterialApp(theme: buildTheme(Brightness.dark), home: BootSplash(kind: BootKind.first, onDone: () {})),
        ),
      );
      await t.pump(Duration(milliseconds: ms));
      await _save(t, 'boot-$ms');
      await t.pump(const Duration(seconds: 3));
    });
  }
  testWidgets('boot short', (t) async {
    t.view.physicalSize = const Size(390, 844);
    t.view.devicePixelRatio = 1.0;
    addTearDown(t.view.resetPhysicalSize);
    await t.pumpWidget(
      RepaintBoundary(
        key: _key,
        child: MaterialApp(theme: buildTheme(Brightness.light), home: BootSplash(kind: BootKind.short, onDone: () {})),
      ),
    );
    await t.pump(const Duration(milliseconds: 900));
    await _save(t, 'boot-short');
    await t.pump(const Duration(seconds: 2));
  });
}
